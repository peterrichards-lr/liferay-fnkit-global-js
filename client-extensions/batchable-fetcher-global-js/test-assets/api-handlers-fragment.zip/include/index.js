const getDataSetSamplesByIds = async (ids) => {
  const PAGE_SIZE = 500;
  const groups = [];
  for (let i = 0; i < ids.length; i += PAGE_SIZE) {
    groups.push(ids.slice(i, i + PAGE_SIZE));
  }

  const results = {};

  // Fetch all groups in parallel
  await Promise.all(groups.map(async group => {
    const filter = `id in (${group.map(id => `'${id}'`).join(',')})`;
    const url = `/o/c/datasetsamples?filter=${encodeURIComponent(filter)}&pageSize=0`;
    const response = await Liferay.Util.fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to fetch dataset samples for IDs: ${group.join(', ')}`);
    }
    const data = await response.json();
    Object.assign(results, Object.fromEntries((data.items || []).map(item => [item.id, item])));
  }));

  return results;
};

const getDataSetImageById = async (id) => {
  const res = await await Liferay.Util.fetch(`/o/c/datasetsamples/${id}/dataSetSampleImage`);
  if (!res.ok) throw new Error(`Failed to fetch image for data set ${id}`);
  return await res.json(); // returns single data set object
};

const getImageDocumentById = async (id) => {
  const res = await await Liferay.Util.fetch(`/o/headless-delivery/v1.0/documents/${id}`);
  if (!res.ok) throw new Error(`Failed to fetch document ${id}`);
  return await res.json(); // returns single document object
};

const fetchDataSetSampleById = Liferay.FnKit.createBatchedFetcher(
  getDataSetSamplesByIds,
  {
    cacheTTL: 10000,
    logger: (level, event, details) => {
      if (level !== 'debug') console.log(`[${level}] ${event}`, details);
    },
  }
);

const fetchDataSetImage = Liferay.FnKit.createBatchedFetcher(
  getDataSetImageById,
  {
    batchable: false, // Important!
    cacheTTL: 5000,
    logger: (level, event, data) => {
      if (level !== 'debug') console.log(`[${level}] ${event}`, data);
    },
  }
);

const fetchImageDocument = Liferay.FnKit.createBatchedFetcher(
  getImageDocumentById,
  {
    batchable: false, // Important!
    cacheTTL: 5000,
    logger: (level, event, data) => {
      if (level !== 'debug') console.log(`[${level}] ${event}`, data);
    },
  }
);

window.fetchDataSetSampleById = fetchDataSetSampleById;
window.fetchDataSetImage = fetchDataSetImage;
window.fetchImageDocument = fetchImageDocument;