if (layoutMode === 'view') {
  const fragmentName = 'data-set-sample-card';
  const fragmentClassPrefix = `${fragmentName}-${fragmentEntryLinkNamespace}`;

  const { imageSize, enableDebug: debugEnabled } = configuration;

  const mappings = (() => {
    const mappingArray = Array.from(
      fragmentElement.querySelector('.config').children
    );
    const mappings = {};

    for (let mapping of mappingArray) {
      const key = mapping.getAttribute('data-lfr-js-id');
      const type = mapping.getAttribute('data-lfr-type');
      const value = mapping.textContent;

      switch (type) {
        case 'bool':
          mappings[key] = value === 'true';
          break;
        case 'int':
          mappings[key] = parseInt(value, 10);
          break;
        default:
          mappings[key] = value;
      }
    }
    return mappings;
  })();

  const debug = (label, ...args) => {
    if (debugEnabled) console.debug(`[Product Badge] ${label}`, ...args);
  };

  const debugWithContext = (label, ...args) => {
    const context = `${mappings.id}`;
    debug(`${label} [${context}]:`, ...args);
  };

  debugWithContext('mappings', mappings);

  debugWithContext('configuration', {
    imageSize,
    debugEnabled,
  });

  fetchDataSetSampleById(mappings.id).then((json) => {
    debugWithContext('entry', json);
    const imageEl = fragmentElement.querySelector(
      `#${fragmentClassPrefix}-image`
    );
    const iconEl = fragmentElement.querySelector(
      `#${fragmentClassPrefix}-icon`
    );
    const headingEl = fragmentElement.querySelector(
      `#${fragmentClassPrefix}-heading`
    );
    const descriptionEl = fragmentElement.querySelector(
      `#${fragmentClassPrefix}-description`
    );
    const linkEl = fragmentElement.querySelector(
      `#${fragmentClassPrefix}-link`
    );
    headingEl.textContent = json.title;
    descriptionEl.textContent = json.description;
    debugWithContext('iconEl', iconEl);

    const iconColor = json.color.name.toLowerCase();
    const iconName = json.icon.name.toLowerCase();

    iconEl.style.color = iconColor;
    const svgEl = iconEl.querySelector('svg');
    svgEl.classList.replace('lexicon-icon-star', `lexicon-icon-${iconName}`);
    const svgUseEl = svgEl.querySelector('use');

    const svgHref = svgUseEl.getAttributeNS(
      'http://www.w3.org/1999/xlink',
      'href'
    );
    const newSvgHref = svgHref.replace('#star', `#${iconName}`);
    svgUseEl.setAttributeNS(
      'http://www.w3.org/1999/xlink',
      'xlink:href',
      newSvgHref
    );

    fetchDataSetImage(mappings.id).then((imageJson) => {
      debugWithContext('imageJson', imageJson);

      const { items } = imageJson;
      const imageItem = items[0];
      imageEl.setAttribute('src', imageItem.image?.thumbnailURL);
      imageEl.setAttribute('alt', json.title);

      const displayPageUrl = `/l/${json.id}`;
      linkEl.setAttribute('href', displayPageUrl);
      linkEl.textContent = json.title;
    });
  });
}
