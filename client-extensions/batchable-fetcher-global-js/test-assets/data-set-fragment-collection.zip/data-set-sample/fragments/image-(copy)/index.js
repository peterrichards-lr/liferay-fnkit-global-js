const mappings = (() => {
    const mappingArray = Array.from(
      fragmentElement.querySelector('.config').children
    );
    const mappings = {};

    for (let mapping of mappingArray) {
      const key = mapping.getAttribute('data-lfr-js-id');
      const type = mapping.getAttribute('data-lfr-type');
      const value = mapping.textContent;

      switch (type) {
        case 'bool':
          mappings[key] = value === 'true';
          break;
        case 'int':
          mappings[key] = parseInt(value, 10);
          break;
        default:
          mappings[key] = value;
      }
    }
    return mappings;
  })();

Liferay.Util.fetch(`/o/c/datasetsamples/${mappings.id}/dataSetSampleImage`)
.then((response) => response.json())
	.then((imageJson) => {
	
	const imageEl = fragmentElement.querySelector('img');
	      const { items } = imageJson;
      const imageItem = items[0];
      imageEl.setAttribute('src', imageItem.image?.thumbnailURL);
});
